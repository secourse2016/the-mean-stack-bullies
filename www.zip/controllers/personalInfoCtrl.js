app.controller('personalInfoCtrl', function($scope, $location,$state,personalInfoSrv,flightSrv) {
      var adults=0;
      var children=0;
      $scope.personalArray=[];
      $scope.nextpassShow=true;
      $scope.ageShow=true;
    
              

           adults=parseInt(flightSrv.getAdultNumber());
           children=parseInt(flightSrv.getChildrenNumber());
           console.log(adults);
           console.log(children);
            $scope.passengersNumber=adults+children;
            console.log($scope.passengersNumber);
            $scope.current=0;
          $scope.passType="Adult";
            if($scope.passengersNumber==1){
               $scope.nextpassShow=false;
            }

 
// 

    $scope.nextpass=function(){
      console.log("IN");
      var err=presonValidations();
      if(err){
        alert("please enter correct info\n"+err);
      }
      else{
          var person=[{
                 firstName      : $scope.firstName,
                 secondName    : $scope.lastName,
             age            : $scope.age,
             nationality    : $scope.Nationality,
               passportNumber: $scope.passportnum,
             issueDate      : $scope.issueDate,
             expiryDate     : $scope.expiryDate
            }];
         console.log(person[0]);
         $scope.personalArray[$scope.current]=person[0];
         $scope.current=$scope.current+1;
         if(adults!=0)
         {
        adults=adults-1;
        $scope.passType="Adult";
         }
         if(adults==0)
         {
          $scope.passType="Child";
           $scope.ageShow=false;
         
         }
         console.log($scope.personalArray);

         $scope.firstName=null;
         $scope.lastName=null;
         $scope.age=null;
         $scope.Nationality=null;
         $scope.issueDate=null;
         $scope.expiryDate=null;
         $scope.passportnum=null;

         if($scope.current==$scope.passengersNumber-1){
          $scope.nextpassShow=false;
         }
      }
    }
    $scope.confirm=function(){
       var err=presonValidations();
      if(err){
        alert("please enter correct info\n"+err);
      }
      else{
        var person=[{
                 firstName      : $scope.firstName,
                 secondName    : $scope.lastName,
             age            : $scope.age,
             nationality    : $scope.Nationality,
               passportNumber: $scope.passportnum,
             issueDate      : $scope.issueDate,
             expiryDate     : $scope.expiryDate
            }];
            
         $scope.personalArray[$scope.current]=person[0];
           $scope.current=$scope.current+1;
         // console.log($scope.personalArray);
         personalInfoSrv.insertPerson($scope.personalArray,function(response){
            // console.log(response);
            $state.go('payment');
         });
       }  
         
    }
  	function presonValidations(){
          var isvalid =true;
          var errMessage = "";
           if($scope.firstName == null||!(/^[a-z ,.'-]+$/i.test($scope.firstName))){
            errMessage+="please enter a valid First name \n";
            isvalid = false;
            }
           if($scope.lastName == null||!(/^[a-z ,.'-]+$/i.test($scope.lastName))){
            errMessage+="please enter a valid Last name \n";
            isvalid = false;
            }
            // if($scope.Nationality == null||!(/^[a-z ,.'-]+$/i.test($scope.Nationality))){
            // errMessage+="please enter a valid Nationality \n";
            // isvalid = false;
            // }

            if(($scope.age == null)||!(/^[0-9]{1,2}$/.test($scope.age ))){
             errMessage+="please enter a valid age \n";
             isvalid =false;
            }

           if($scope.passportnum == null||!(/^[0-9]{8}$/.test($scope.passportnum))){
            errMessage+="please enter a valid Passport Number \n";
            isvalid = false;
            }
           // if($scope.issueDate== null){
           //   errMessage+="please choose the issue date \n";
           //   isvalid =false;
           //  } 
           if($scope.expiryDate== null){
             errMessage+="please choose choose expiry date \n";
             isvalid =false;
            }
           if(isvalid == true){
            errMessage = null;
           }
           return errMessage;
      }
  });



app.factory('personalInfoSrv',function ($http){ 
       return {
         insertPerson : function(pe,cb) {
          var tokenReq = {
              method: 'GET',
              url: 'http://52.26.173.245/getToken'
            };
      return $http(tokenReq).success(function(response){
          var req = {
              method: 'POST',
              url: 'http://52.26.173.245/api/insertperson?wt='+response,
              data: { people: pe }
                 
          };
          
          return $http(req)

              .success(function(response) {
                console.log("hereeeeee"+response);
                   cb(response);
              })
              .error(function(data, status, headers, config) {
                  console.log(response.statusText);
                  alert("An error occured please try again");
          });
            }).error(function(response){
                console.log(response.statusText);
                alert("An error occured please try again");
            });

         },
getBookingNumberOfAdultsAndChildren : function(cb){
        var tokenReq = {
              method: 'GET',
              url: 'http://52.26.173.245/getToken'
            };
      return $http(tokenReq).success(function(response){
        var req = {
          method: 'GET',
          url: 'http://52.26.173.245/api/getBookingNumberOfAdultsAndChildren?wt='+response
      };
        return $http(req)
              .success(function(response) {
                     console.log("in the person service"+response);
                   cb(response);
              })
              .error(function(response) {
                   console.log(response.statusText);
                alert("An error occured please try again");
              });
            }).error(function(response){
                console.log(response.statusText);
                alert("An error occured please try again");
            });
         }

     };
    });
 